To Execute My Codes:

1. Create a folder.

2. Place 
ICML(unpacked), MainProcess.py(main code), stopwords.txt
in the folder.

3. Open MainProcess.py, and execute it!



###################

result.txt is result of class named ��7. Kernel Methods��.

word_vector.txt is the order of Word Vector for every article.